﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NETWEB.Models
{
    public class SearchResultViewModel
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}