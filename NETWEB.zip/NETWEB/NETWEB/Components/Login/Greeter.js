
import React, {Component} from 'react'
import './css/Greeter.css';
import 'bootstrap/dist/css/bootstrap.min.css'
class Greeter extends Component{
  render() {
    return (
      <div>
        <input type="button" value="按钮" className="btn btn-default" />
        <div className="root">dddddd</div>
      </div>
    );
  }
}
export default Greeter