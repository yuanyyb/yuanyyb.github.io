import React from 'react';
import {render} from 'react-dom';
import Greeter from './Login/Greeter';
render(<Greeter />, document.getElementById('root'));