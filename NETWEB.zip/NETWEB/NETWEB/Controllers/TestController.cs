﻿using NETWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NETWEB.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

        public ActionResult AddContent()
        {
            Model.Books model = new Model.Books();
            model.AurhorDescription = "sdhflkasjflaksdjf";
            model.Author = "老赵";
            model.CategoryId = 1;
            model.Clicks = 1;
            model.ContentDescription = "老赵的私人生活是......???";
            model.EditorComment = "adfsadfsadf";
            model.ISBN = "39u582349";
            model.PublishDate = DateTime.Now;
            model.PublisherId = 72;
            model.Title = "私生活";
            model.TOC = "aaaaaaaaaaaaaaaa";
            model.UnitPrice = 22.3m;
            model.WordsCount = 1234;

            //1：先存储到数据库中。
            //2:向Lucene.Net中添加.
            SearchIndexManager.GetInstance().AddOrUpdateQueue("10000", model.Title, model.ContentDescription);
            return Content("ok");
        }

    }
}
