﻿using IBLL;
using Model;
using Spring.Context;
using Spring.Context.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NETWEB.Controllers
{
    public class BaseController : Controller
    {
        //
        // GET: /Base/
        public UserInfo LoginUserInfo { get; set; }
        //控制器,需要登录的功能继承此控制器
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            //sping容器直接使用
            //IApplicationContext ctx = ContextRegistry.GetContext();
            //IUserInfoBLL UserInfoBLL = (IUserInfoBLL)ctx.GetObject("UserInfoBLL");

            bool isExt = false;

            if (Request.Cookies["sessionId"]!=null)
            {
                string sessionId = Request.Cookies["sessionId"].Value;
                object obj = Common.MemcacheHelper.Get(sessionId);
                if (obj!=null)
                {
                    //1.验证用户登录
                    UserInfo user = Common.SerializerHelper.DeserializeToObject<UserInfo>(obj.ToString());
                    LoginUserInfo = user;
                    Common.MemcacheHelper.Set(sessionId, obj, DateTime.Now.AddMinutes(20));//登录状态向后延迟20分钟
                    //留下一个后门，方便程序员调试程序。但是发布系统时一定要移除该后门。
                    if (user.UName == "yyb")
                    {
                        return;
                    }
                    isExt = true;
                    //2.验证角色权限
                }
            }
            if (!isExt)
            {
                filterContext.Result = Redirect("/UserLogin/LoginView");
            }

        }

    }
}
