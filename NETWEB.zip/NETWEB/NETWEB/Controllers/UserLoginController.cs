﻿using IBLL;
using Model;
using NETWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NETWEB.Controllers
{
    public class UserLoginController : Controller
    {
        //
        // GET: /UserLogin/
        IUserInfoBLL UserInfoBLL { get; set; }

        #region 验证码
        public ActionResult ShowValidate()
        {
            Common.ValidateCode validateCode = new Common.ValidateCode();
            string code = validateCode.CreateValidateCode(4);
            Session["vcode"] = code;
            byte[] buffer = validateCode.CreateValidateGraphic(code);
            return File(buffer, "image/jpeg");
        }
        #endregion


        /// <summary>
        /// 登录
        /// </summary>
        /// <returns></returns>
        public ActionResult Login()
        {
            //string s = Common.WebCommon.GetMd5String("1");
            ResultJson result = new ResultJson();
            string account = Request.Form["account"];
            string pwd = Request.Form["pwd"];//前端加密后的密码
            string vcode = Request.Form["vcode"];
            string saveuser = Request.Form["issave"];
            //检查验证码
            if (string.IsNullOrWhiteSpace(vcode))
            {
                result.code = -1;
                result.msg = "请填写验证码!";
            }
            else
            {
                if (string.IsNullOrWhiteSpace(account))
                {
                    result.code = -1;
                    result.msg = "请输入用户名!";
                }
                else
                {
                    //根据用户名查询用户表中是否有该用户
                    UserInfo user = UserInfoBLL.LoadEntities(u => u.UName == account&&u.UPwd==pwd&&u.DelFlag==0).FirstOrDefault<UserInfo>();
                    if (user != null)
                    {
                        string sessionId = Guid.NewGuid().ToString();
                        Common.MemcacheHelper.Set(sessionId, Common.SerializerHelper.SerializerToString(user), DateTime.Now.AddMinutes(20));//将用户对象存memcache
                        Response.Cookies["sessionId"].Value = sessionId;//将KEY以Cookie的形式返回给浏览器。
                        //if (!string.IsNullOrWhiteSpace(saveuser))//选中保持登录状态，写cookie保存，异步ajax登录保存登录在前端保存cookie
                        //{
                        //    HttpCookie cookie1 = new HttpCookie("cu1", user.UName);
                        //    HttpCookie cookie2 = new HttpCookie("cu2", Common.WebCommon.GetMd5String(Common.WebCommon.GetMd5String(user.UPwd)));
                        //    cookie1.Expires = DateTime.Now.AddDays(3);//设置3天免登录
                        //    cookie2.Expires = DateTime.Now.AddDays(3);
                        //    Response.Cookies.Add(cookie1);
                        //    Response.Cookies.Add(cookie2);
                        //    Response.Redirect("Home/Index");
                        //}
                    }
                    else
                    {
                        result.code = -1;
                        result.msg = "用户名或密码错误!";
                    }
                }
            }
            return Json(result);
        }

        public ActionResult LoginView() 
        {
            return View();
        }

    }
}
