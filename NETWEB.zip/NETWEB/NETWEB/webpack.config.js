const webpack = require('webpack');
module.exports = {
    //js编译的入口文件
    entry:  {
        login:__dirname + "/Components/main.js"
    },
    output: {
      path: __dirname + "/public",//打包后的文件存放的地方
      filename: "[name].js"//打包后输出文件的文件名
    },
    devtool: 'eval-source-map',
    module: {
        rules: [
            {
                test: /(\.jsx|\.js)$/,
                use: {
                    loader: "babel-loader"
                },
                exclude: /node_modules/
            },
            {
                test: /\.css$/,
                use: [
                    {
                        loader: "style-loader"
                    }, {
                        loader: "css-loader"
                    }
                ]
            },
            { test: /\.eot(\?v=\d+\.\d+\.\d+)?$/, loader: "file" },
            { test: /\.(woff|woff2)$/, loader:"url?prefix=font/&limit=5000" },
            { test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/, loader: "url?limit=10000&mimetype=application/octet-stream" },
            { test: /\.svg(\?v=\d+\.\d+\.\d+)?$/, loader: "url?limit=10000&mimetype=image/svg+xml" }
        ]
    },
    plugins: [
        new webpack.BannerPlugin('版权所有，翻版必究！！'),
        new webpack.ProvidePlugin({
            $: "jquery",
                jQuery: "jquery",
                'window.$':'jquery',
                'window.jQuery':'jquery'
        })
    ]
  }